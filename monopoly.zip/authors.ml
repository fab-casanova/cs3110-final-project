let hours_worked = 18
